const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3')
const { DynamoDBClient, ScanCommand } = require('@aws-sdk/client-dynamodb')
const { readableStreamToString } = require('./util.cjs')

const s3 = new S3Client({})
const ddb = new DynamoDBClient({})

module.exports.handler = async (event) => {
	const bucket = process.env.BUCKET_NAME
	const table = process.env.TABLE_NAME
	const route = event?.rawPath || ''

	// naïve: pick most recent job by updatedAt
	const scan = await ddb.send(new ScanCommand({ TableName: table }))
	const items = (scan.Items || []).sort((a, b) => (a.updatedAt?.S || '').localeCompare(b.updatedAt?.S || ''))
	const latest = items[items.length - 1]
	if (!latest) return { statusCode: 200, body: JSON.stringify({ message: 'No jobs yet' }) }

	const s3Key = (keyAttr) => latest[keyAttr]?.S

	if (route.endsWith('/latest/status')) {
		return { statusCode: 200, body: JSON.stringify({ valid: latest.status?.S === 'VALID', message: latest.status?.S }) }
	}

	if (route.endsWith('/latest/path')) {
		const obj = await s3.send(new GetObjectCommand({ Bucket: bucket, Key: s3Key('pathKey') }))
		const body = await readableStreamToString(obj.Body)
		// Ensure the frontend gets { path: { points: [...] } }
		let parsed
		try { parsed = JSON.parse(body) } catch { parsed = { points: [] } }
		const normalized = Array.isArray(parsed?.points) ? parsed : { points: [] }
		return { statusCode: 200, body: JSON.stringify({ path: normalized }) }
	}

	if (route.endsWith('/latest/code')) {
		const karelObj = await s3.send(new GetObjectCommand({ Bucket: bucket, Key: s3Key('karelKey') }))
		const krlObj = await s3.send(new GetObjectCommand({ Bucket: bucket, Key: s3Key('krlKey') }))
		const [karel, krl] = await Promise.all([
			readableStreamToString(karelObj.Body),
			readableStreamToString(krlObj.Body)
		])
		return { statusCode: 200, body: JSON.stringify({ karel, krl }) }
	}

	return { statusCode: 404, body: JSON.stringify({ error: 'Not found' }) }
}
